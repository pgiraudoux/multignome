pkgname <- "multignome"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
options(pager = "console")
library('multignome')

assign(".oldSearch", search(), pos = 'CheckExEnv')
cleanEx()
nameEx("etaV2prob")
### * etaV2prob

flush(stderr()); flush(stdout())

### Name: etaV2prob
### Title: Link Functions
### Aliases: etaV2prob real2data
### Keywords: regression

### ** Examples

# coming soon



cleanEx()
nameEx("extractXY")
### * extractXY

flush(stderr()); flush(stdout())

### Name: extractXY
### Title: Internal Functions For Fitting Multinomial Models
### Aliases: extractXY parNames grad.givenIndex grad.gnome
### Keywords: regression

### ** Examples

# See multiGnome



cleanEx()
nameEx("findMnStart")
### * findMnStart

flush(stderr()); flush(stdout())

### Name: findMnStart
### Title: search for non-naive starting values
### Aliases: findMnStart
### Keywords: regression

### ** Examples

# No Examples



cleanEx()
nameEx("mergeLevels")
### * mergeLevels

flush(stderr()); flush(stdout())

### Name: mergeLevels
### Title: Evaluates a set of multinomial models
### Aliases: mergeLevels mergeLevels_2
### Keywords: regression

### ** Examples

library(nnet)
data("serxu")
multinom(cbind(empty, Mili, Miir, Mile, Crka) ~ habitat + night, data=serxu)$AIC
multinom(cbind(empty, Mili, Miir, Mile, Crka) ~ habitat, data=serxu)$AIC

## So there is a night effect.

## What do you think? Should automate the following?
m1 <- mergeLevels(cbind(empty, Mili, Miir, Mile, Crka)~habitat + night, serxu, "habitat")
levels(serxu$habitat)[c(3,13)] <- "cg_sb" ## Corresponds to lowest deltaAIC
m2 <- mergeLevels(cbind(empty, Mili, Miir, Mile, Crka)~habitat + night, serxu, "habitat")
levels(serxu$habitat)[c(2,10)] <- "bv_rs"
m3 <- mergeLevels(cbind(empty, Mili, Miir, Mile, Crka)~habitat + night,serxu, "habitat")
levels(serxu$habitat)[c(4,12)] <- "dg_ug"
m4 <- mergeLevels(cbind(empty, Mili, Miir, Mile, Crka)~habitat + night,serxu, "habitat")
levels(serxu$habitat)[c(5,10)] <- "fg_sx"
m5 <- mergeLevels(cbind(empty, Mili, Miir, Mile, Crka)~habitat + night,serxu, "habitat")
levels(serxu$habitat)[c(6,7)] <- "mt_mg"
m6 <- mergeLevels(cbind(empty, Mili, Miir, Mile, Crka)~habitat + night,serxu, "habitat")
levels(serxu$habitat)[c(5,8)] <- "fg_sx_pv"
m7 <- mergeLevels(cbind(empty, Mili, Miir, Mile, Crka)~habitat + night,serxu, "habitat")
levels(serxu$habitat)[c(2,8)] <- "bv_rs_sg"
m8 <- mergeLevels(cbind(empty, Mili, Miir, Mile, Crka)~habitat + night,serxu, "habitat")
min(m8)



cleanEx()
nameEx("multignome")
### * multignome

flush(stderr()); flush(stdout())

### Name: multignome
### Title: The Gnome
### Aliases: multignome combineFrames gnome
### Keywords: regression

### ** Examples

# A function to derive unscaled AIC from fitted values of multinom
sumRowDs <- function(dataProb) {
  n <- length(dataProb) /2   # half vector length
  dmultinom(dataProb[1:n],prob=dataProb[n+1:n],log=TRUE)
}
 
library(nnet)
# Simulate Data
nSpecies <- 2
nTrapNights <- 50
nExplain <- 2
nTrapsPerLine <- 25
simData <- simMnData(nSpecies,nTrapNights,nExplain,nTrapsPerLine)
sim <- as.data.frame(cbind(simData,attr(simData,"dataMat")))
colnames(sim) <- c(paste("y",0:nSpecies,sep=""), paste("x",0:nExplain,sep=""))

# Fit model using multinom in nnet library
ripMN <- multinom(cbind(y0,y1,y2)~x1+x2, sim)
# Fir model using gnome
modelList <- list(y0~0,y1~x1+x2,y2~x1+x2)
myMG <- multignome(modelList,data=sim)

# Ripley's  coefficients
t(coefficients(ripMN))
# Our coefficients 
myMG$params
# True values of coefficients
attr(simData,"pars")

# Ripley's log likelihood
sum(apply(cbind(sim[,1+(0:nSpecies)],ripMN$fitted),1,"sumRowDs"))
# Our log likelihood
myMG$value



cleanEx()
nameEx("runMerges")
### * runMerges

flush(stderr()); flush(stdout())

### Name: runMerges
### Title: Merge classes of explanatory factor of a multinomial model
### Aliases: runMerges

### ** Examples

library(nnet)
data(metalSm)
formula <- cbind(Apsy,Mygl,Crle,Crru,Miag,Miar,Mimi,Mumu,Misu,Soar,Somi,empty) ~ habitat 
fit <- multinom(cbind(Apsy,Mygl,Crle,Crru,Miag,Miar,Mimi,Mumu,Misu,Soar,Somi,empty)~habitat,data=metalSm)
try <- runMerges(formula,data=metalSm,fit=fit)



### * <FOOTER>
###
cat("Time elapsed: ", proc.time() - get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
