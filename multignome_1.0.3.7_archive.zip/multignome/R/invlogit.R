invlogit <- function(eta) exp(eta) / (1 + exp(eta))
