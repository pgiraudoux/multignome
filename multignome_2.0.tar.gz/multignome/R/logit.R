logit <- function(p) log(p / (1-p))

